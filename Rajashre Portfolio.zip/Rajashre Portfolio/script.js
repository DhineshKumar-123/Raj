(function(){
  // Theme toggle (simple dark/light)
  const btn = document.getElementById('themeToggle');
  const root = document.documentElement;
  const current = localStorage.getItem('theme') || 'dark';
  function applyTheme(t){
    if(t === 'light'){
      root.style.setProperty('--bg-1','#f7fafc');
      root.style.setProperty('--bg-2','#eef2f7');
      root.style.setProperty('--card','rgba(2,6,23,0.04)');
      root.style.setProperty('--glass','rgba(2,6,23,0.03)');
      root.style.setProperty('--ghost-border','rgba(11,18,32,0.06)');
      root.style.setProperty('color-scheme','light');
      document.body.style.color = '#0b1220';
      btn?.setAttribute('aria-pressed','true');
    } else {
      root.style.removeProperty('--bg-1');
      root.style.removeProperty('--bg-2');
      root.style.removeProperty('--card');
      root.style.removeProperty('--glass');
      root.style.removeProperty('--ghost-border');
      root.style.setProperty('color-scheme','dark');
      document.body.style.color = '';
      btn?.setAttribute('aria-pressed','false');
    }
  }
  applyTheme(current);
  btn?.addEventListener('click',()=>{
    const next = (localStorage.getItem('theme')||'dark') === 'dark' ? 'light' : 'dark';
    localStorage.setItem('theme',next);
    applyTheme(next);
  });

  // smooth in-page links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      const href = a.getAttribute('href');
      if(href.length>1){
        e.preventDefault();
        document.querySelector(href)?.scrollIntoView({behavior:'smooth',block:'start'});
      }
    });
  });

  // Reveal elements when they scroll into view (smooth entrance)
  const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function onVisibility(entries, obs){
    entries.forEach(entry=>{
      if(!entry.isIntersecting) return;

      // If this reveal contains a stagger container, animate children with a small delay
      const staggerContainer = entry.target.querySelector && entry.target.querySelector('.stagger');
      if(staggerContainer){
        const items = staggerContainer.querySelectorAll('.project');
        items.forEach((it, i) => {
          const delay = prefersReduced ? 0 : i * 120;
          setTimeout(()=> it.classList.add('is-visible'), delay);
        });
        obs.unobserve(entry.target);
        return;
      }

      entry.target.classList.add('is-visible');
      obs.unobserve(entry.target);
    });
  }

  // If the browser doesn't support IntersectionObserver (older browsers),
  // reveal everything immediately so content isn't hidden by CSS.
  if(!('IntersectionObserver' in window)){
    document.querySelectorAll('.reveal').forEach(entry=>{
      // if it contains a stagger container, reveal children
      const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
      if(staggerContainer){
        staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
      }
      entry.classList.add('is-visible');
    });
  } else {
    // Use try/catch in case creating the observer throws in some environments
    try{
      const observer = new IntersectionObserver(onVisibility, {threshold: 0.12});
      document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

      // Fallback: if the observer doesn't trigger (or is blocked), reveal after a short delay
      // This ensures content is not left hidden in edge cases.
      setTimeout(()=>{
        document.querySelectorAll('.reveal').forEach(entry=>{
          if(!entry.classList.contains('is-visible')){
            const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
            if(staggerContainer){
              staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
            }
            entry.classList.add('is-visible');
          }
        });
      }, 700);

    }catch(e){
      // If the observer cannot be created for any reason, reveal everything immediately.
      document.querySelectorAll('.reveal').forEach(entry=>{
        const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
        if(staggerContainer){
          staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
        }
        entry.classList.add('is-visible');
      });
    }
  }

  // Subtle floating name animation (respect reduced motion)
  if(!prefersReduced){
    const nameEl = document.querySelector('.name');
    nameEl?.classList.add('float');
  }

  // Avatar modal: open/close when avatar is clicked
  const avatar = document.getElementById('avatarImg');
  const modal = document.getElementById('avatarModal');
  const modalClose = modal?.querySelector('.modal-close');
  const modalBackdrop = modal?.querySelector('.modal-backdrop');

  function openModal(){
    if(!modal) return;
    modal.setAttribute('aria-hidden','false');
    modal.classList.add('open');
    // trap focus simply on close button
    modalClose?.focus();
  }
  function closeModal(){
    if(!modal) return;
    modal.setAttribute('aria-hidden','true');
    modal.classList.remove('open');
    avatar?.focus();
  }

  avatar?.addEventListener('click', openModal);
  modalClose?.addEventListener('click', closeModal);
  modalBackdrop?.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeModal(); });

})();