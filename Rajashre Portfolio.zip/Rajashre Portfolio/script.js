(function(){
  // Theme toggle (simple dark/light)
  const btn = document.getElementById('themeToggle');
  const root = document.documentElement;
  const current = localStorage.getItem('theme') || 'light';
  function applyTheme(t){
    // set data attribute so CSS can smoothly switch variables
    root.setAttribute('data-theme', t);
    if(t === 'dark'){
      root.style.setProperty('--page-bg','#0f1724');
      root.style.setProperty('--text-color','#e6eef6');
      root.style.setProperty('--muted','#9aa4b2');
      root.style.setProperty('--card','rgba(255,255,255,0.04)');
      root.style.setProperty('--glass','rgba(255,255,255,0.03)');
      root.style.setProperty('--ghost-border','rgba(255,255,255,0.06)');
      document.body.style.color = 'var(--text-color)';
      btn?.setAttribute('aria-pressed','true');
      btn?.setAttribute('aria-label','Switch to light theme');
    } else {
      root.setAttribute('data-theme','light');
      root.style.setProperty('--page-bg','#ffffff');
      root.style.setProperty('--text-color','#0b1220');
      root.style.setProperty('--muted','#334155');
      root.style.setProperty('--card','rgba(11,18,32,0.04)');
      root.style.setProperty('--glass','rgba(11,18,32,0.03)');
      root.style.setProperty('--ghost-border','rgba(11,18,32,0.06)');
      document.body.style.color = 'var(--text-color)';
      btn?.setAttribute('aria-pressed','false');
      btn?.setAttribute('aria-label','Switch to dark theme');
    }
  }
  applyTheme(current);
  btn?.addEventListener('click',()=>{
    const next = (localStorage.getItem('theme')||current) === 'light' ? 'dark' : 'light';
    localStorage.setItem('theme',next);
    applyTheme(next);
  });

  // smooth in-page links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      const href = a.getAttribute('href');
      if(href.length>1){
        e.preventDefault();
        document.querySelector(href)?.scrollIntoView({behavior:'smooth',block:'start'});
      }
    });
  });

  // Reveal elements when they scroll into view (smooth entrance)
  const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function onVisibility(entries, obs){
    entries.forEach(entry=>{
      if(!entry.isIntersecting) return;

      // If this reveal contains a stagger container, animate children with a small delay
      const staggerContainer = entry.target.querySelector && entry.target.querySelector('.stagger');
      if(staggerContainer){
        const items = staggerContainer.querySelectorAll('.project');
        items.forEach((it, i) => {
          const delay = prefersReduced ? 0 : i * 120;
          setTimeout(()=> it.classList.add('is-visible'), delay);
        });
        obs.unobserve(entry.target);
        return;
      }

      entry.target.classList.add('is-visible');
      obs.unobserve(entry.target);
    });
  }

  // If the browser doesn't support IntersectionObserver (older browsers),
  // reveal everything immediately so content isn't hidden by CSS.
  if(!('IntersectionObserver' in window)){
    document.querySelectorAll('.reveal').forEach(entry=>{
      // if it contains a stagger container, reveal children
      const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
      if(staggerContainer){
        staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
      }
      entry.classList.add('is-visible');
    });
  } else {
    // Use try/catch in case creating the observer throws in some environments
    try{
      const observer = new IntersectionObserver(onVisibility, {threshold: 0.12});
      document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

      // Fallback: if the observer doesn't trigger (or is blocked), reveal after a short delay
      // This ensures content is not left hidden in edge cases.
      setTimeout(()=>{
        document.querySelectorAll('.reveal').forEach(entry=>{
          if(!entry.classList.contains('is-visible')){
            const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
            if(staggerContainer){
              staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
            }
            entry.classList.add('is-visible');
          }
        });
      }, 700);

    }catch(e){
      // If the observer cannot be created for any reason, reveal everything immediately.
      document.querySelectorAll('.reveal').forEach(entry=>{
        const staggerContainer = entry.querySelector && entry.querySelector('.stagger');
        if(staggerContainer){
          staggerContainer.querySelectorAll('.project').forEach(it => it.classList.add('is-visible'));
        }
        entry.classList.add('is-visible');
      });
    }
  }

  // Subtle floating name animation (respect reduced motion)
  if(!prefersReduced){
    const nameEl = document.querySelector('.name');
    nameEl?.classList.add('float');
  }

  // Avatar modal: open/close when avatar is clicked
  const avatar = document.getElementById('avatarImg');
  const modal = document.getElementById('avatarModal');
  const modalClose = modal?.querySelector('.modal-close');
  const modalBackdrop = modal?.querySelector('.modal-backdrop');

  function openModal(){
    if(!modal) return;
    modal.setAttribute('aria-hidden','false');
    modal.classList.add('open');
    // trap focus simply on close button
    modalClose?.focus();
  }
  function closeModal(){
    if(!modal) return;
    modal.setAttribute('aria-hidden','true');
    modal.classList.remove('open');
    avatar?.focus();
  }

  avatar?.addEventListener('click', openModal);
  modalClose?.addEventListener('click', closeModal);
  modalBackdrop?.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeModal(); });

})();