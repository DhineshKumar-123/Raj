# Rajashre Rajesware — Portfolio (Static)

This repository now contains a clean static HTML/CSS/JS portfolio.

Files added:

- `index.html` — main portfolio page (semantic, responsive)
- `styles.css` — modern CSS with variables and responsive layout
- `script.js` — small JS for theme toggle and smooth scroll

How to view locally:

- Option A (open file): double-click `index.html` in Explorer or right-click -> Open With -> Browser.
- Option B (simple HTTP server): from PowerShell run:

```powershell
# if Python is installed
python -m http.server 8000
# then open http://localhost:8000
```

Next steps (optional):

- Replace text and project links with live project URLs or GitHub repos.
- Add screenshots, CV download, or contact form.
- Deploy to GitHub Pages, Netlify, or Vercel.

If you'd like, I can:

- convert this to a React/Vite site,
- add animations or dark-mode refinements,
- or prepare a deployment config for GitHub Pages.
